<?php
$servername="localhost";
$username= "root";
$password="";
$dbname="ec";
$connection = new mysqli($servername, $username, $password, $dbname);
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home page</title>
</head>
<body>
        <form method="post">
        <h1>Welcome to Our E-Commerce Store</h1>

        <input type="text" name="search" placeholder="Search">
        <input type="submit" name="submit">
        <br>
        <?php
        if (isset($_POST["submit"])) {
            header("location:search.php");
            $a = $_POST["search"];
            $sql = "SELECT * FROM `search` WHERE Name = '$a'";
            $res = $connection->query($sql);
            if ($res->num_rows > 0) {
                $resArray = array();
                while ($row = $res->fetch_assoc()) {
                    $resArray[] = $row;
                }
                $_SESSION['search_result'] = $resArray;
            } else {
                echo "No results";
            }
            $connection->close();
        }
        ?>
        <?php
        if (isset($_POST["add"])){
            header("location:cart.php");
            $sql = "SELECT * From `search` WHERE Name = ?";
        } 
        ?>
        <section class="product-listing">
        <h2>Featured Products</h2>
            <div class="product">
                <img src="product1.jpg" alt="Product 1">
                <h3>Product 1</h3>
                <p>Description of Product 1. Price: $20</p>
                <button type="submit" name="add">Add to cart</button><br>
            </div>
            <br>
            <div class="product">
                <img src="product2.jpg" alt="Product 2">
                <h3>Product 2</h3>
                <p>Description of Product 2. Price: $30</p>
                <button type="submit" name="add">Add to cart</button><br>
                <input type="hidden" name="prd1">
            </div>
            <br>
            <div class="product">
                <img src="product3.jpg" alt="Product 3">
                <h3>Product 3</h3>
                <p>Description of Product 3. Price: $50</p>
                <button type="submit" name="add">Add to cart</button><br>
            </div>
        </section>
        </form>
</body>
</html>