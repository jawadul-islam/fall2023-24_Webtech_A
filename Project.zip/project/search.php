<?php
session_start();
if (isset($_SESSION['search_result'])) {
    $resArray = $_SESSION['search_result'];
    
} else {
    echo "No results in session.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>
    <table border="1">
        <tr>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
        </tr>
        <?php foreach ($resArray as $row) { ?>
        <tr>
            <td><?php echo $row["Name"]; ?></td>
            <td><?php echo $row["Description"]; ?></td>
            <td><?php echo $row["Price"]; ?></td>
        </tr>
    <?php } ?>

    </table>
</body>
</html>




