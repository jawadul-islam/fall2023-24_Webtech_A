<?php
$servername="localhost";
$username= "root";
$password="";
$dbname="ec";
$connection= new mysqli($servername,$username,$password,$dbname);
if(isset($_GET['register'])){
    $name = $_GET['name'];
    $number = $_GET['pnumber'];
    $email = $_GET['email'];
    $password = $_GET['pass'];  
    if(empty($name && $number && $email && $password)){
        echo "Fill the form properly";
    }else{
        $sql= "INSERT INTO info VALUES ('$name', '$number', '$email', '$password')";
        mysqli_query($connection,$sql);
        echo "You've registered successfully!!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
</head>
<body>
    <h1>REGISTRATION PAGE</h1>
	<form method="get" action="">
    <input type="text" name="name" placeholder="Name"><br>
    <br>
    <input type="text" name="pnumber" placeholder="Phone Number"><br>
    <br>
	<input type="text" name="email" placeholder="Email"><br>
    <br>
	<input type="password" name="pass" placeholder="Password"><br>
    <br>
	<button type="submit" name="register">Submit</button><br>
    <br>
    <button type="submit" name="btn"><a href="login.php">Login page</button>
    </form>

</body>
</html>
