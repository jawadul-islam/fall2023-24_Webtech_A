<?php
$servername="localhost";
$username= "root";
$password="";
$dbname="ec";
$connection = new mysqli($servername, $username, $password, $dbname);
$email = '';
$pass = '';
if(isset($_GET['login']))
{
	$email=$_GET['email'];
	$pass=$_GET['pass'];
	$sql= "select * from info where Email = '$email' and Password = '$pass'";
	$res= mysqli_query($connection,$sql);
	if($res->num_rows>0)
	{
		while($r=mysqli_fetch_assoc($res))
	{
		$_SESSION['email']=$r["Email"];

		header("location: home.php");
	}
	}
	else
	{
		echo "Invalid User";
	}
	
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
	<form method="get" action="">
        <h1>LOGIN PAGE</h1>
	    <input type="text" name="email" placeholder="Email"><br>
        <br>
		<input type="password" name="pass" placeholder="Password"><br>
        <br>
		<button type="submit" name="login">Login</button><br>
        <br>
		<button type="submit" name="register"><a href="register.php">Register</button>
	</form>
</body>
</html>
